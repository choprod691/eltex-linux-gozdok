#!/usr/bin/env bash

FIFO=""

# launch parameters
for arg in "$@"; do
    case "$arg" in
        --pishitesuda=*)
            FIFO="${arg#*=}"
            ;;
        *)
            echo "Unknown parameter: $arg" >&2
            exit 1
            ;;
    esac
done

# check channel specification and definition with absolute path
if [[ -z "$FIFO" || "$FIFO" != /* ]]; then
    echo "Using: $0 --pishitesuda=/absolute/channel/path" >&2
    exit 1
fi

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="$SCRIPT_DIR/cuckoo.log"

# fuction adding message to log
log_message() {
    printf '%s %s\n' \
        "$(date '+%Y-%m-%d %H:%M:%S')" \
        "$*" >> "$LOG_FILE"
}

# function correct temination
shutdown() {
    log_message "Shutdown!"
    rm -f -- "$FIFO"
    exit 0
}

# SIGTERM to stop
# SIGINT to Ctrl+C stop
trap shutdown TERM INT

# don't delete file if in path
if [[ -e "$FIFO" && ! -p "$FIFO" ]]; then
    echo "Error: $FIFO exist and not named channel" >&2
    exit 1
fi

# create channel if not exist
if [[ ! -p "$FIFO" ]]; then
    mkfifo "$FIFO" || exit 1
fi

log_message "Startup!"

# open channel for read/write on descriptor 3
# descriptoe denies read end of EOF
exec 3<>"$FIFO"

REQUEST_RE='^([^[]+)\[([0-9]+)\]: how much time do I have\?$'

# main request cycle
while IFS= read -r request <&3; do
    if [[ $request =~ $REQUEST_RE ]]; then
        name="${BASH_REMATCH[1]}"
        pid="${BASH_REMATCH[2]}"
        number=$((RANDOM % 9 + 2))

        log_message "${name}[${pid}] ${number}"

        # create channel for response
        response_fifo="/tmp/cuckoo_response_${pid}"

        if [[ -p "$response_fifo" ]]; then
            printf '%s\n' "$number" > "$response_fifo"
        fi
    fi
done
