#!/usr/bin/env bash

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="$SCRIPT_DIR/observer.conf"
LOG_FILE="$SCRIPT_DIR/observer.log"

# reports created in scripts directory
cd "$SCRIPT_DIR" || exit 1

log_message() {
    printf '%s %s\n' \
        "$(date '+%Y-%m-%d %H:%M:%S')" \
        "$*" >> "$LOG_FILE"
}

if [[ ! -f "$CONFIG_FILE" ]]; then
    echo "Can't find file configuration: $CONFIG_FILE" >&2
    exit 1
fi

# read configuration one by one
while IFS= read -r task || [[ -n "$task" ]]; do
    # skip clear lines and comments
    [[ -z "$task" || "$task" == \#* ]] && continue

    # path is relative to observer.sh.
    if [[ "$task" != /* ]]; then
        task="$SCRIPT_DIR/$task"
    fi

    if [[ ! -x "$task" ]]; then
        log_message "Error: $task does not exist or does not executable"
        continue
    fi

    running=0

    # find exact path by procfs.
    for cmdline in /proc/[0-9]*/cmdline; do
        [[ -r "$cmdline" ]] || continue

        while IFS= read -r -d '' arg; do
            if [[ "$arg" == "$task" ]]; then
                running=1
                break 2
            fi
        done < "$cmdline" 2>/dev/null
    done

    if ((running == 0)); then
        log_message "Task $task not found in /proc, restarting..."

        nohup "$task" </dev/null \
            >> "$SCRIPT_DIR/nohup.log" 2>&1 &
    fi
done < "$CONFIG_FILE"
