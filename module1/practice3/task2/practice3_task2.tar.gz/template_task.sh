#!/usr/bin/env bash

# take script start name
SCRIPT_NAME="${0##*/}"

# tamplate don't do the job
if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit 0
fi

# report created in directory
REPORT_FILE="report_${SCRIPT_NAME}.log"
RESPONSE_FIFO="/tmp/cuckoo_response_$$"
FIFO=""

log_message() {
    printf '%s %s\n' \
        "$(date '+%Y-%m-%d %H:%M:%S')" \
        "$*" >> "$REPORT_FILE"
}

# delete temporary response
cleanup() {
    rm -f -- "$RESPONSE_FIFO"
}
trap cleanup EXIT

log_message "[$$] Script start"

# find cuckoo.sh and parameters with procfs
for cmdline in /proc/[0-9]*/cmdline; do
    [[ -r "$cmdline" ]] || continue

    # cmdline arguments devided by nulls
    # nulls are spaces now
    args="$(tr '\0' ' ' < "$cmdline" 2>/dev/null)"

    if [[ "$args" == *cuckoo.sh* && \
          "$args" =~ --pishitesuda=([^[:space:]]+) ]]; then
        FIFO="${BASH_REMATCH[1]}"
        break
    fi
done

if [[ -z "$FIFO" || ! -p "$FIFO" ]]; then
    echo "Can't find cuckoo.sh channel with procfs" >&2
    exit 1
fi

# channel for server respons
rm -f -- "$RESPONSE_FIFO"
mkfifo "$RESPONSE_FIFO"

# server request
printf '%s\n' \
    "${SCRIPT_NAME}[$$]: how much time do I have?" > "$FIFO"

# take resonse
if ! IFS= read -r N < "$RESPONSE_FIFO"; then
    echo "Failed to receive resonse cuckoo.sh" >&2
    exit 1
fi

# check that number from 2 to 10.
if [[ ! "$N" =~ ^[2-9]$ && "$N" != "10" ]]; then
    echo "Received incorrect respons: $N" >&2
    exit 1
fi

sleep "$N"

log_message "[$$] Script is finished and was running $N seconds"
